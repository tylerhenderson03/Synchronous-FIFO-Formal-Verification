`default_nettype none


module FIFO_tb
#(parameter D_WIDTH = 4,
  parameter DEPTH   = 4)

 (input  wire clk, rst,
  input  wire wr_req, rd_req,
  input  wire [D_WIDTH-1:0] data_in,
  input wire start_tracking, 

  input  wire wr_ack, rd_ack,
  input  wire full, empty,
  input  wire [D_WIDTH-1:0] data_out);

  ///////////////////////////
  // INCLUDE YOUR CODE HERE//
  ///////////////////////////

// if our tb counter shows the FIFO is full, we should also see that the DUT says it is full too
  a_full: assert property(@(posedge clk) disable iff(rst) reg_counter == DEPTH |-> full);

// if our tb counter shows the FIFO is empty, we should also see that the DUT says it is empty too
  a_empty: assert property(@(posedge clk) disable iff(rst)  reg_counter == 0 |-> empty);

/*
valid wr/rd only occurs when a wr/rd_req is met with a wr/rd_ack on the same clock cycle.
wr/rd_ack's are driven with C.L.
*/
  a_valid_wr: assert property(@(posedge clk) disable iff(rst) wr_req |-> wr_ack);
  a_valid_rd: assert property(@(posedge clk) disable iff(rst) rd_req |-> rd_ack);

// assume that we can see either a wr_req, OR a rd_req, OR neither, but not both
// since wr_req and rd_req are inputs, we use an "assume" property to tell jasper how to guide the test cases we input here
  a_no_simulatneous_wr_rd: assume property(@(posedge clk) !(wr_req & rd_req));

/*
at ANY edge of the clk, if we see start tracking asserted,
this means on the next clock cycle, we should see it continue to be
asserted throughout the functionality of our program
*/
  as_st_stable: assume property(@(posedge clk) start_tracking |=> $stable(start_tracking));

/*
if we see start_tracking rise on a given clk cycle (with the previous property, it will only rise once)
then we should also see that when it has risen, that wr_ack should have been
asserted as well for a valid write to the FIFO/DUT
*/
  as_st_write: assume property (@(posedge clk) $rose(start_tracking) |-> wr_ack);

//asserts that the current value of counter is less than or equal to the previous value of counter
  a_counter_dec: assert property (@(posedge clk) disable iff(~start_tracking) start_tracking |=> ( ($past(counter) > counter) || ($past(counter) == counter) ));

/*
do not track if "start_tracking" is de-asserted.
if counter(number of elements in front of tracked element) is zero, and there's a rd_ack,
then the popped element should equal our tracked element
*/
  a_popped: assert property (@(posedge clk) disable iff(~start_tracking) counter == 0 |=>);

// Spec no. 11: Verify that it is possible to start tracking an element
  start_track_element: assert property(@(posedge clk) )

// Spec no. 14: Verify that done_tracking is never asserted before start_tracking


  reg [$clog2(DEPTH):0] reg_counter;
  reg [$clog2(DEPTH):0] counter;

  logic valid_wr, valid_rd;
  assign valid_wr = wr_req & wr_ack;
  assign valid_rd = rd_req & rd_ack;

  bit done_tracking;
  always_ff @(posedge clk) begin
    done_tracking <= (rd_ack & (data_out == track_me));
  end

  always_ff @(posedge clk, posedge rst) begin
    if (rst) reg_counter <= '0;
    else if (valid_wr)  reg_counter <= reg_counter + 1;
    else if (valid_rd) reg_counter <= reg_counter - 1;
  end

  always_ff @(posedge clk, posedge rst) begin
    if (rst) counter <= '0;
    else if (start_tracking) begin // if start_tracking is asserted, only decrease on a read, else don't increase
      if (valid_rd & ~empty & counter != '0) counter <= counter - 1;
    end
    else begin
      if (valid_wr & ~full)  counter <= counter + 1;
      else if (valid_rd & ~empty) counter <= counter - 1;
    end
  end

  reg [D_WIDTH-1:0] track_me;

  always_ff @(posedge start_tracking) begin
    track_me <= data_in; // track_me gets the very next value of data_in once start_tracking asserted
  end

    

endmodule: FIFO_tb
